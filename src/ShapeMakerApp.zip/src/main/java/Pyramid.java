public class Pyramid {

  // Variables
  private double l;
  private double w;
  private double h;

  // Constructor

  public Pyramid() {
    l = 0;
    w = 0;
    h = 0;
  }

  // Set methods

  public void setLength(double length) {
    this.l = length;
  }

  public void setWidth(double width) {
    this.w = width;
  }

  public void setHeight(double height) {
    this.h = height;
  }

  // Volume Calculation

  public double calcVol() {
    double vol = (l * w * h)/3;
    return vol;
  }

  // Surface Area Calculation

  public double calcSurfArea() {
    double surfA = l * w + l * Math.sqrt((w / 2) * (w / 2) + h * h) + w * Math.sqrt((l / 2) * (l / 2) + h * h);
    return surfA;
  }
}