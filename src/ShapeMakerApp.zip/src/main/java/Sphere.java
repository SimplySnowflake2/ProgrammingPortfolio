public class Sphere {

  // Variables
  private double r;

  // Constructor

  public Sphere() {
    r = 0;
  }

  // Set methods

  public void setRadius(double radius) {
    this.r = radius;
  }

  // Volume Calculation

  public double calcVol() {
    double vol = (4 * Math.PI * r * r * r)/3;
    return vol;
  }

  // Surface Area Calculation

  public double calcSurfArea() {
    double surfA = 4 * Math.PI * r * r;
    return surfA;
  }
}