public class Box {

  // Variables
  private double l;
  private double w;
  private double h;

  // Constructor
  public Box() {
    l = 0;
    w = 0;
    h = 0;
  }

  // Set methods
  public void setLength(double length) {
    this.l = length;
  }

  public void setWidth(double width) {
    this.w = width;
  }

  public void setHeight(double height) {
    this.h = height;
  }

  // Volume Calculation
  public double calcVol() {
    double vol = l * w * h;
    return vol;
  }

  // Surface Area Calculation
  public double calcSurfArea() {
    double surfA = 2 * (l * w + l * h + w * h);
    return surfA;
  }
}