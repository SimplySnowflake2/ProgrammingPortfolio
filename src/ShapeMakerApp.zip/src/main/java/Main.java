// import static org.junit.jupiter.api.Assertions.assertEquals;
// import org.junit.jupiter.api.Test;

import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    // Print Statement Welcoming User to the Game/App and Basic Information
    System.out.println("Welcome to the 'Shape Maker App!' Lets find the volume and surface area for a few shapes...");
    System.out.println("To build a box, press 1");
    System.out.println("To build a pyramid, press 2");
    System.out.println("To build a sphere, press 3");

    // Create a Scanner to Take in User Input
    Scanner input = new Scanner(System.in);

    // Create a variable to store the user's input
    int userInput = input.nextInt();

    // To create a box, the user must enter 1
    if (userInput == 1) {
      System.out.println("Great! Let's make a box!");
      Box box1 = new Box();
      System.out.println("Please enter the length of your box:");
      box1.setLength(input.nextDouble());
      System.out.println("Please enter the width of your box:");
      box1.setWidth(input.nextDouble());
      System.out.println("Please enter the height of your box:");
      box1.setHeight(input.nextDouble());
      System.out.println("The volume of your box: " + box1.calcVol());
      System.out.println("The surface area of your box: " + box1.calcSurfArea());

      // To create a pyramid, the user must enter 2
    } else if (userInput == 2) {
      System.out.println("Great! Let's make a pyramid!");
      Pyramid pyramid1 = new Pyramid();
      System.out.println("Please enter the length of your pyramid:");
      pyramid1.setLength(input.nextDouble());
      System.out.println("Please enter the width of your pyramid:");
      pyramid1.setWidth(input.nextDouble());
      System.out.println("Please enter the height of your pyramid:");
      pyramid1.setHeight(input.nextDouble());
      System.out.println("The volume of your pyramid: " + pyramid1.calcVol());
      System.out.println("The surface area of your pyramid: " + pyramid1.calcSurfArea());

      // To create a sphere, the user must enter 3
    } else if (userInput == 3) {
      System.out.println("Great! Let's make a sphere!");
      Sphere sphere1 = new Sphere();
      System.out.println("Please enter the radius of your sphere:");
      sphere1.setRadius(input.nextDouble());
      System.out.println("The volume of your sphere: " + sphere1.calcVol());
      System.out.println("The surface area of your box: " + sphere1.calcSurfArea());

      // If the user enters a number that is not 1, 2, or 3, the program will print an
      // error message
    } else {
      System.out.println("Invalid input. Please enter a number between 1 and 3.");
    }

    // Once they've gone through one shape, allow the user to play again
    System.out.println("");
    System.out.println("Would you like to play again?");
    System.out.println("Enter 1 to play again or 2 to exit:");
    int playAgainInput = input.nextInt();
    if (playAgainInput == 1) {
      // restart the process
      main(args);
    } else if (playAgainInput == 2) {
      System.out.println("Thank you for using the 'Shape Maker App'. Goodbye!");
    } else {
      System.out.println("Invalid input. A number between 1 and 2 was not entered. Game will automatically end.");
      System.out.println("Thank you for using the 'Shape Maker App'. Goodbye!");
    }

    // Close the Scanner
    input.close();
  }
  // @Test
  // void addition() {
  // assertEquals(2, 1 + 1);
  // }
}